//
// EventArgs.cpp
//
// Library: Foundation
// Package: Events
// Module:  EventArgs
//
// Implementation of EventArgs
//
// Copyright (c) 2006, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#include "Poco/EventArgs.h"


namespace Poco {


EventArgs::EventArgs()
{
}


EventArgs::~EventArgs()
{
}


} // namespace Poco
